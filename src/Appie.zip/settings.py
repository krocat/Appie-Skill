#Settings file for the Appie skill
username = "Your AH.nl username"
password = "Your AH.nl password"
applicationID = "amzn1.ask.skill.xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
